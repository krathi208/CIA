// Fetch Random Dog Image
document.getElementById('fetch-dog-image').addEventListener('click', function () {
    fetch('https://dog.ceo/api/breeds/image/random')
        .then(response => response.json())
        .then(data => {
            const imgContainer = document.getElementById('dog-image-container');
            imgContainer.innerHTML = `<img src="${data.message}" alt="Random Dog Image">`;
        })
        .catch(error => console.error('Error fetching dog image:', error));
});


// Fetch Dog Breeds from GitHub JSON file
fetch('https://raw.githubusercontent.com/krathi208/JSON/main/dog-breeds.json')
    .then(response => response.json())
    .then(data => {
        const breedsContainer = document.getElementById('dog-breeds-container');
        data.forEach(breed => {
            const breedCard = document.createElement('div');
            breedCard.classList.add('breed-card');
            breedCard.innerHTML = `
                <h3>${breed.breedName}</h3>
                <img src="${breed.imageUrl}" alt="${breed.breedName}">
                <p>${breed.description}</p>
                <p><strong>Size:</strong> ${breed.size}</p>
                <p><strong>Lifespan:</strong> ${breed.lifespan}</p>
                <p><strong>Origin:</strong> ${breed.origin}</p>
            `;
            breedsContainer.appendChild(breedCard);
        });
    })
    .catch(error => console.error('Error fetching dog breeds:', error));

